import os

from google import genai

GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")


def _client():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is missing. Create a .env file and add your Gemini API key."
        )
    return genai.Client(api_key=api_key)


def answer_question(question: str) -> str:
    question = (question or "").strip()
    if not question:
        return "Please enter a question."

    try:
        prompt = f"""
You are EduGenie, an educational assistant.
Answer the student's question accurately and concisely.
Use simple language appropriate for a learner.
If the question needs steps, provide numbered steps.
Do not invent facts when you are uncertain.

Student question:
{question}
"""
        response = _client().models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt
        )
        return (response.text or "").strip() or "No answer was generated."

    except Exception as exc:
        return f"Unable to get an answer from Gemini: {exc}"
