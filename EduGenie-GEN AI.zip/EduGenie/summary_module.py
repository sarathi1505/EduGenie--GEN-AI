import os

from google import genai

GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")


def _client():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is missing. Create a .env file and add your Gemini API key."
        )
    return genai.Client(api_key=api_key)


def summarize_text(text: str) -> str:
    text = (text or "").strip()
    if not text:
        return "Please enter text to summarize."

    try:
        prompt = f"""
Summarize the following educational passage for quick revision.

Requirements:
- Keep the important information.
- Remove unnecessary repetition.
- Use simple language.
- Prefer short paragraphs and bullet points.
- Do not add facts that are not present in the passage.

Passage:
{text}
"""

        response = _client().models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt
        )
        return (response.text or "").strip() or "No summary was generated."

    except Exception as exc:
        return f"Unable to summarize the text: {exc}"
