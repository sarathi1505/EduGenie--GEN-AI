import json
import os
import re

from google import genai

GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")


def _client():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is missing. Create a .env file and add your Gemini API key."
        )
    return genai.Client(api_key=api_key)


def clean_json_block(text: str) -> str:
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def generate_quiz(passage: str):
    passage = (passage or "").strip()
    if not passage:
        return {"error": "Please enter a topic or passage."}

    prompt = f"""
Create exactly 3 multiple-choice questions from the educational text below.

Return ONLY valid JSON in this exact structure:
{{
  "questions": [
    {{
      "question": "Question text",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "answer": "The exact correct option text",
      "explanation": "Short explanation"
    }}
  ]
}}

Rules:
- Exactly 3 questions.
- Exactly 4 options per question.
- One correct answer.
- Questions must be answerable from the supplied text.
- Distractors should be plausible.
- No Markdown and no code fences.

Educational text:
{passage}
"""

    try:
        response = _client().models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt
        )

        raw = clean_json_block(response.text)
        data = json.loads(raw)

        if not isinstance(data, dict) or not isinstance(data.get("questions"), list):
            raise ValueError("Gemini returned an invalid quiz structure.")

        questions = data["questions"][:3]
        if len(questions) != 3:
            raise ValueError("Gemini did not return exactly 3 questions.")

        for q in questions:
            if not isinstance(q.get("options"), list) or len(q["options"]) != 4:
                raise ValueError("Each quiz question must have exactly 4 options.")

        return {"questions": questions}

    except Exception as exc:
        return {"error": f"Quiz generation failed: {exc}"}
