import os
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from explanation_module import explain_topic
from qna import answer_question
from quiz_module import generate_quiz
from summary_module import summarize_text
from learning_path import get_learning_recommendations

load_dotenv()

app = FastAPI(
    title="EduGenie - Google Gemini Powered Learning Assistant",
    version="1.0.0",
    description="AI-powered educational assistant built with FastAPI."
)

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/qa")
async def qa(question: str = Form(...)):
    return {"result": answer_question(question)}


@app.post("/explain")
async def explain(topic: str = Form(...)):
    return {"result": explain_topic(topic)}


@app.post("/quiz")
async def quiz(text: str = Form(...)):
    return {"result": generate_quiz(text)}


@app.post("/summarize")
async def summarize(text: str = Form(...)):
    return {"result": summarize_text(text)}


@app.post("/learn/recommendations")
async def learning_recommendations(topic: str = Form(...), level: Optional[str] = Form("Beginner")):
    return {"result": get_learning_recommendations(topic, level or "Beginner")}


@app.get("/health")
async def health():
    return {"status": "ok", "service": "EduGenie"}
