import os

from google import genai

GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")


def _client():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is missing. Create a .env file and add your Gemini API key."
        )
    return genai.Client(api_key=api_key)


def get_learning_recommendations(topic: str, level: str = "Beginner") -> str:
    topic = (topic or "").strip()
    level = (level or "Beginner").strip()

    if not topic:
        return "Please enter a topic."

    try:
        prompt = f"""
Create a personalized learning path for the topic "{topic}".
Learner level: {level}

Organize it from beginner to advanced where appropriate.

Include:
1. Prerequisites
2. Beginner concepts
3. Intermediate concepts
4. Advanced concepts
5. A suggested weekly timeline
6. Practice/project ideas
7. Useful resource types such as videos, articles, documentation, or books
8. A short final revision plan

Keep the plan practical and easy for a student to follow.
"""

        response = _client().models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt
        )
        return (response.text or "").strip() or "No learning path was generated."

    except Exception as exc:
        return f"Unable to generate the learning path: {exc}"
