import os
from functools import lru_cache

from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

MODEL_NAME = os.getenv("LOCAL_EXPLANATION_MODEL", "MBZUAI/LaMini-Flan-T5-783M")


@lru_cache(maxsize=1)
def _load_model():
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)
    return tokenizer, model


def explain_topic(topic: str) -> str:
    topic = (topic or "").strip()
    if not topic:
        return "Please enter a topic to explain."

    try:
        tokenizer, model = _load_model()

        prompt = (
            "Explain the following educational topic in simple language for a student. "
            "Use short sections and a small example where useful. "
            f"Topic: {topic}"
        )

        inputs = tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=512
        )

        outputs = model.generate(
            **inputs,
            max_new_tokens=220,
            num_beams=4,
            no_repeat_ngram_size=3,
            early_stopping=True
        )

        result = tokenizer.decode(outputs[0], skip_special_tokens=True).strip()
        if result:
            return result

    except Exception as exc:
        # The local model is intentionally optional at runtime.
        return (
            "The local LaMini-Flan-T5 explanation model could not be loaded. "
            "Install the model dependencies and try again.\n\n"
            f"Technical detail: {exc}"
        )

    return "I could not generate an explanation for that topic."
